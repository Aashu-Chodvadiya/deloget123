import React from 'react';
import { Link } from 'react-router-dom';
import './Careers.css';
import softwareImage from './assets/images/Software.svg';
import teamImage from './assets/images/team.svg';
import aiImage from './assets/images/ai.svg';
import appImage from './assets/images/app.svg';
import uiImage from './assets/images/ui.svg';
import platformImage from './assets/images/Platform.svg';

const Careers = () => {
  return (
    <div className="careers-page">
      <header className="careers-header">
        <div className="header-content">
          <div className="logo-section">
            <img src={softwareImage} alt="Logo" className="logo-image" />
          </div>
          <nav className="nav-menu">
            <Link to="/" className="nav-link">Home</Link>
            <Link to="/about" className="nav-link">About</Link>
            <Link to="/services" className="nav-link">Services</Link>
            <Link to="/blog" className="nav-link">Blog</Link>
            <Link to="/contact" className="nav-link">Contact</Link>
            <Link to="/careers" className="nav-link active">Careers</Link>
          </nav>
          <div className="auth-buttons">
            <Link to="/login" className="sign-in-btn">Sign In</Link>
            <Link to="/login" className="sign-up-btn">Sign Up</Link>
          </div>
        </div>
      </header>

      <main className="careers-main">
        <section className="hero-section">
          <div className="hero-content">
            <h1>Build Your Career in Web Development</h1>
            <p>Join our team of passionate developers and educators. Discover exciting career opportunities in the ever-evolving world of web technologies.</p>
            <img src={teamImage} alt="Hero" className="hero-image" />
          </div>
        </section>

        <section className="overview-section">
          <h2>Career Opportunities at Our Education Platform</h2>
          <p>We are a leading provider of web development education, and we're always looking for talented individuals to join our growing team. Whether you're a seasoned developer, an educator, or someone passionate about technology, we have opportunities that match your skills and interests.</p>
          <img src={aiImage} alt="Overview" className="section-image" />
        </section>

        <section className="open-positions">
          <h2>Current Open Positions</h2>

          <div className="position-detail">
            <h3>Senior Web Developer</h3>
            <p>As a Senior Web Developer, you'll be responsible for designing, developing, and maintaining high-quality web applications. This role involves working with modern frameworks, ensuring code quality, and mentoring junior developers.</p>
            <ul>
              <li>5+ years of experience in web development</li>
              <li>Proficiency in React, Node.js, and modern JavaScript</li>
              <li>Experience with database design and API development</li>
              <li>Strong problem-solving and communication skills</li>
              <li>Mentoring and team leadership experience</li>
            </ul>
            <p>This position offers competitive salary, remote work options, and opportunities for professional growth. You'll work on cutting-edge projects that impact thousands of learners worldwide.</p>
            <img src={softwareImage} alt="Senior Web Developer" className="position-image" />
          </div>

          <div className="position-detail">
            <h3>Educational Content Creator</h3>
            <p>Create engaging and informative educational content for our web development courses. This role combines technical expertise with teaching skills to develop comprehensive learning materials.</p>
            <ul>
              <li>Strong background in web development</li>
              <li>Experience in creating technical tutorials or courses</li>
              <li>Excellent writing and communication skills</li>
              <li>Knowledge of modern teaching methodologies</li>
              <li>Familiarity with e-learning platforms</li>
            </ul>
            <p>You'll have the opportunity to shape the learning experience for aspiring developers, working on diverse topics from basic HTML to advanced full-stack development.</p>
            <img src={uiImage} alt="Content Creator" className="position-image" />
          </div>

          <div className="position-detail">
            <h3>DevOps Engineer</h3>
            <p>Manage our infrastructure and deployment pipelines to ensure reliable, scalable, and secure web applications. This role is crucial for maintaining the high availability of our educational platform.</p>
            <ul>
              <li>Experience with cloud platforms (AWS, Azure, GCP)</li>
              <li>Proficiency in containerization (Docker, Kubernetes)</li>
              <li>Knowledge of CI/CD pipelines and automation tools</li>
              <li>Strong understanding of security best practices</li>
              <li>Experience with monitoring and logging systems</li>
            </ul>
            <p>Join our infrastructure team to build and maintain the backbone of our educational technology, ensuring seamless learning experiences for our users.</p>
            <img src={platformImage} alt="DevOps Engineer" className="position-image" />
          </div>

          <div className="position-detail">
            <h3>UI/UX Designer</h3>
            <p>Design intuitive and beautiful user interfaces for our educational platform. This role focuses on creating engaging learning experiences through thoughtful design.</p>
            <ul>
              <li>Proven experience in UI/UX design</li>
              <li>Proficiency in design tools (Figma, Sketch, Adobe XD)</li>
              <li>Understanding of user-centered design principles</li>
              <li>Experience with web and mobile design</li>
              <li>Knowledge of accessibility standards</li>
            </ul>
            <p>You'll work closely with developers and educators to create interfaces that make learning web development enjoyable and effective.</p>
            <img src={appImage} alt="UI/UX Designer" className="position-image" />
          </div>

          <div className="position-detail">
            <h3>Technical Support Specialist</h3>
            <p>Provide exceptional support to our learners, helping them navigate technical challenges and maximize their learning experience.</p>
            <ul>
              <li>Strong technical background in web development</li>
              <li>Excellent customer service and communication skills</li>
              <li>Experience with learning management systems</li>
              <li>Problem-solving and troubleshooting abilities</li>
              <li>Patience and empathy in user interactions</li>
            </ul>
            <p>This role is perfect for someone who loves helping others while staying connected to the latest web technologies.</p>
            <img src={teamImage} alt="Technical Support" className="position-image" />
          </div>
        </section>

        <section className="benefits-section">
          <h2>Why Work With Us?</h2>
          <div className="benefits-grid">
            <div className="benefit">
              <img src={softwareImage} alt="Innovation" />
              <h4>Innovative Environment</h4>
              <p>Work on cutting-edge projects using the latest web technologies and methodologies.</p>
            </div>
            <div className="benefit">
              <img src={aiImage} alt="Learning" />
              <h4>Continuous Learning</h4>
              <p>Access to training, conferences, and opportunities to expand your skills.</p>
            </div>
            <div className="benefit">
              <img src={teamImage} alt="Collaboration" />
              <h4>Collaborative Culture</h4>
              <p>Join a supportive team where ideas are valued and collaboration is key.</p>
            </div>
            <div className="benefit">
              <img src={platformImage} alt="Impact" />
              <h4>Make an Impact</h4>
              <p>Your work directly contributes to educating the next generation of developers.</p>
            </div>
            <div className="benefit">
              <img src={uiImage} alt="Flexibility" />
              <h4>Work-Life Balance</h4>
              <p>Flexible schedules, remote work options, and generous time off policies.</p>
            </div>
            <div className="benefit">
              <img src={appImage} alt="Growth" />
              <h4>Career Growth</h4>
              <p>Clear paths for advancement and professional development opportunities.</p>
            </div>
          </div>
        </section>

        <section className="application-process">
          <h2>Our Application Process</h2>
          <p>We strive to make our hiring process efficient and transparent. Here's what you can expect:</p>
          <div className="process-steps">
            <div className="step">
              <h4>1. Application Review</h4>
              <p>Our team reviews your application and resume to assess your fit for the role.</p>
            </div>
            <div className="step">
              <h4>2. Initial Interview</h4>
              <p>A conversation with our HR team to discuss your experience and motivations.</p>
            </div>
            <div className="step">
              <h4>3. Technical Assessment</h4>
              <p>Depending on the role, you may complete coding challenges or design tasks.</p>
            </div>
            <div className="step">
              <h4>4. Team Interview</h4>
              <p>Meet with potential colleagues to discuss how you'd contribute to our team.</p>
            </div>
            <div className="step">
              <h4>5. Offer and Onboarding</h4>
              <p>If selected, you'll receive a competitive offer and begin our comprehensive onboarding process.</p>
            </div>
          </div>
        </section>

        <section className="contact-section">
          <h2>Ready to Join Our Team?</h2>
          <p>Take the first step towards an exciting career in web development education. We're excited to hear from you!</p>
          <button className="apply-button">View Open Positions</button>
        </section>
      </main>

      <footer className="careers-footer">
        <p>&copy; 2025 Education Platform. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Careers;