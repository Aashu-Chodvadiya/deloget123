import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Home.css';
import Logo1 from './assets/logo/logo-1.svg'
import Image1 from './assets/images/image-1.png'
import Logo2 from './assets/images/logo-2.svg'
import Image3 from './assets/images/call.svg'
import Image4 from './assets/images/arrow.png'
import Image5 from './assets/images/Psychological.svg'
import Image6 from './assets/images/Leetcode.svg'
import Image7 from './assets/images/team.svg'
import Image8 from './assets/images/Software.svg'
import Image9 from './assets/images/testing.svg'
import Image10 from './assets/images/ai.svg'
import Image11 from './assets/images/app.svg'
import Image12 from './assets/images/ui.svg'
import Image13 from './assets/images/Platform.svg'
import Image14 from './assets/images/node.jpg'
import Image15 from './assets/images/python.jpg'
import Image16 from './assets/images/node1.jpg'

function Home() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768) {
        setIsSidebarOpen(true);
      } else {
        setIsSidebarOpen(false);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };
  return (
    <div className="home-page">
      <header className="home-header">
        <div className="header-content">
          <button className="sidebar-toggle" onClick={toggleSidebar}>
            <span className="hamburger"></span>
            <span className="hamburger"></span>
            <span className="hamburger"></span>
          </button>
          <div className="logo-section">
            <img src={Logo1} alt="logo-1" className="logo-image" />
          </div>
          <nav className="nav-menu">
            <Link to="/" className="nav-link active">Home</Link>
            <Link to="/services" className="nav-link">Services</Link>
            <Link to="/about" className="nav-link">About</Link>
            <Link to="/blog" className="nav-link">Blog</Link>
            <Link to="/contact" className="nav-link">Contact</Link>
            <Link to="/login" className="nav-link">Login</Link>
          </nav>
          <button className="cta-button">Schedule a Call</button>
        </div>
      </header>

      <div className="home-content">
        <aside className={`sidebar ${isSidebarOpen ? 'open' : ''}`}>
          <div className="sidebar-section">
            <h3>Course Categories</h3>
            <ul>
              <li><Link to="/services">Web Development</Link></li>
              <li><Link to="/services">Programming Languages</Link></li>
              <li><Link to="/services">Data Science</Link></li>
              <li><Link to="/services">Mobile Development</Link></li>
              <li><Link to="/services">DevOps</Link></li>
            </ul>
          </div>
          <div className="sidebar-section">
            <h3>Popular Topics</h3>
            <ul>
              <li><Link to="/blog">React.js Guide</Link></li>
              <li><Link to="/blog">Python for Beginners</Link></li>
              <li><Link to="/blog">Machine Learning Basics</Link></li>
              <li><Link to="/blog">UI/UX Design</Link></li>
            </ul>
          </div>
          <div className="sidebar-section">
            <h3>Quick Links</h3>
            <ul>
              <li><Link to="/about">About Us</Link></li>
              <li><Link to="/contact">Contact Support</Link></li>
              <li><Link to="/login">Student Portal</Link></li>
              <li><a href="#">FAQ</a></li>
            </ul>
          </div>
          <div className="sidebar-image">
            <img src={Image16} alt="Sidebar" />
          </div>
        </aside>

        <main className={`main-content ${isSidebarOpen ? 'sidebar-open' : ''}`}>
          <section className="hero-section">
            <div className="hero-content">
              <h1>Master Web Development: Your Complete Learning Journey</h1>
              <p>Embark on a comprehensive educational path to become a proficient web developer. Our platform offers in-depth courses, hands-on projects, and expert guidance to transform you into a skilled professional in the digital world.</p>
              <img src={Image1} alt="Hero" className="hero-image" />
            </div>
          </section>

          <section className="welcome-section">
            <h2>Welcome to Our Education Platform</h2>
            <p>Our mission is to provide high-quality, accessible education in web development and programming. We believe that everyone should have the opportunity to learn and grow in the tech industry, regardless of their background or experience level.</p>
            <p>With over 4,000+ timezone-aligned software engineers and experts, we offer a unique learning experience that combines theoretical knowledge with practical application. Our courses are designed to take you from beginner to advanced levels, ensuring you gain the skills needed to succeed in today's competitive job market.</p>
            <img src={Image14} alt="Welcome" className="section-image" />
          </section>

          <section className="learning-path-section">
            <h2>Your Web Development Learning Path</h2>
            <p>Our structured learning approach ensures you build a solid foundation and progressively advance your skills. Here's a detailed overview of what you'll learn:</p>

            <div className="learning-detail">
              <h3>Foundations of Web Development</h3>
              <p>Start with the basics that form the backbone of all web technologies. This comprehensive foundation covers essential concepts that every web developer must master.</p>
              <ul>
                <li>HTML5: Semantic markup, forms, multimedia integration</li>
                <li>CSS3: Responsive design, flexbox, grid layouts, animations</li>
                <li>JavaScript Fundamentals: Variables, functions, DOM manipulation</li>
                <li>Version Control: Git and GitHub for collaborative development</li>
                <li>Browser Developer Tools: Debugging and performance optimization</li>
              </ul>
              <p>These foundational skills provide the building blocks for all advanced web development concepts. You'll learn through interactive exercises and real-world projects that demonstrate practical application.</p>
              <img src={Image15} alt="Foundations" className="learning-image" />
            </div>

            <div className="learning-detail">
              <h3>Front-End Development Mastery</h3>
              <p>Dive deep into modern front-end frameworks and libraries that power today's web applications. Learn to create dynamic, interactive user interfaces.</p>
              <ul>
                <li>React.js: Component-based architecture, state management, hooks</li>
                <li>Vue.js: Progressive framework for building user interfaces</li>
                <li>Angular: Full-featured framework for complex applications</li>
                <li>TypeScript: Adding type safety to JavaScript development</li>
                <li>State Management: Redux, Context API, and modern patterns</li>
              </ul>
              <p>Master the art of creating responsive, performant web applications that provide exceptional user experiences. Our courses include hands-on projects that simulate real-world development scenarios.</p>
              <img src={Image12} alt="Front-End" className="learning-image" />
            </div>

            <div className="learning-detail">
              <h3>Back-End Development and APIs</h3>
              <p>Learn server-side programming, database management, and API development to build complete web applications.</p>
              <ul>
                <li>Node.js: Server-side JavaScript runtime environment</li>
                <li>Express.js: Web application framework for Node.js</li>
                <li>Database Design: SQL and NoSQL database systems</li>
                <li>RESTful APIs: Designing and implementing web services</li>
                <li>Authentication: JWT, OAuth, and security best practices</li>
              </ul>
              <p>Understand the server-side of web development, including data persistence, user authentication, and scalable architecture design. Build full-stack applications that handle real user data and interactions.</p>
              <img src={Image13} alt="Back-End" className="learning-image" />
            </div>

            <div className="learning-detail">
              <h3>DevOps and Deployment</h3>
              <p>Master the tools and practices for deploying, maintaining, and scaling web applications in production environments.</p>
              <ul>
                <li>Containerization: Docker for application packaging</li>
                <li>Cloud Platforms: AWS, Azure, Google Cloud deployment</li>
                <li>CI/CD Pipelines: Automated testing and deployment</li>
                <li>Monitoring: Application performance and error tracking</li>
                <li>Security: Web application security and best practices</li>
              </ul>
              <p>Learn to bridge the gap between development and operations, ensuring your applications are reliable, scalable, and secure in production environments.</p>
              <img src={Image8} alt="DevOps" className="learning-image" />
            </div>
          </section>

          <section className="why-choose-section">
            <h2>Why Choose Our Education Platform?</h2>
            <div className="reasons-grid">
              <div className="reason">
                <img src={Image7} alt="Expert Instructors" />
                <h4>Expert Instructors</h4>
                <p>Learn from industry professionals with years of experience in web development and software engineering.</p>
              </div>
              <div className="reason">
                <img src={Image6} alt="Hands-on Projects" />
                <h4>Hands-on Projects</h4>
                <p>Apply your knowledge through real-world projects that build your portfolio and demonstrate your skills.</p>
              </div>
              <div className="reason">
                <img src={Image5} alt="Flexible Learning" />
                <h4>Flexible Learning</h4>
                <p>Study at your own pace with lifetime access to course materials and 24/7 support.</p>
              </div>
              <div className="reason">
                <img src={Image10} alt="Career Support" />
                <h4>Career Support</h4>
                <p>Get help with job placement, resume building, and interview preparation to launch your tech career.</p>
              </div>
            </div>
          </section>

          <section className="testimonials-section">
            <h2>What Our Students Say</h2>
            <div className="testimonials">
              <div className="testimonial">
                <p>"This platform transformed my career. The comprehensive web development courses gave me the skills I needed to land my dream job as a front-end developer."</p>
                <cite>- Sarah Johnson, Front-End Developer</cite>
              </div>
              <div className="testimonial">
                <p>"The hands-on approach and expert instructors made learning complex topics like React and Node.js enjoyable and easy to understand."</p>
                <cite>- Michael Chen, Full-Stack Developer</cite>
              </div>
              <div className="testimonial">
                <p>"The career support was invaluable. I not only learned to code but also got help with my resume and interview preparation."</p>
                <cite>- Emily Rodriguez, Software Engineer</cite>
              </div>
            </div>
          </section>

          <section className="cta-section">
            <h2>Ready to Start Your Web Development Journey?</h2>
            <p>Join thousands of students who have transformed their careers through our comprehensive education platform.</p>
            <div className="cta-buttons">
              <Link to="/services" className="cta-primary">Explore Courses</Link>
              <Link to="/contact" className="cta-secondary">Contact Us</Link>
            </div>
          </section>
        </main>
      </div>

      <footer className="home-footer">
        <div className="footer-content">
          <div className="footer-section">
            <h4>About Us</h4>
            <p>We provide comprehensive education in web development, programming, and related technologies to help you build a successful career in tech.</p>
          </div>
          <div className="footer-section">
            <h4>Quick Links</h4>
            <ul>
              <li><Link to="/services">Services</Link></li>
              <li><Link to="/about">About</Link></li>
              <li><Link to="/blog">Blog</Link></li>
              <li><Link to="/contact">Contact</Link></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Support</h4>
            <ul>
              <li><a href="#">Help Center</a></li>
              <li><a href="#">FAQ</a></li>
              <li><Link to="/contact">Contact Support</Link></li>
              <li><a href="#">System Status</a></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Connect</h4>
            <ul>
              <li><a href="#">Facebook</a></li>
              <li><a href="#">Twitter</a></li>
              <li><a href="#">LinkedIn</a></li>
              <li><a href="#">YouTube</a></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; 2025 Education Platform. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default Home;