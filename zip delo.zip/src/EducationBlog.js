import React from 'react';
import { Link } from 'react-router-dom';
import './EducationBlog.css';
import node1Image from './assets/images/node1.avif';
import pythonImage from './assets/images/python.jpg';
import nodeImage from './assets/images/node.jpg';
import uiImage from './assets/images/ui.svg';
import aiImage from './assets/images/ai.svg';
import appImage from './assets/images/app.svg';
import platformImage from './assets/images/Platform.svg';
import softwareImage from './assets/images/Software.svg';

const EducationBlog = () => {
  const blogPosts = [
    {
      id: 1,
      title: 'Introduction to Programming',
      image: node1Image,
      description: 'Learn the basics of programming with this comprehensive guide.',
      category: 'Beginner'
    },
    {
      id: 2,
      title: 'Advanced JavaScript Concepts',
      image: pythonImage,
      description: 'Dive deep into closures, prototypes, and async programming.',
      category: 'Advanced'
    },
    {
      id: 3,
      title: 'Data Structures and Algorithms',
      image: nodeImage,
      description: 'Master the fundamentals of DSA for better problem-solving.',
      category: 'Intermediate'
    },
    {
      id: 4,
      title: 'Web Development Best Practices',
      image: uiImage,
      description: 'Tips and tricks for building modern web applications.',
      category: 'Web Dev'
    },
    {
      id: 5,
      title: 'Machine Learning Basics',
      image: aiImage,
      description: 'Get started with machine learning algorithms and models.',
      category: 'AI/ML'
    },
    {
      id: 6,
      title: 'Mobile App Development',
      image: appImage,
      description: 'Build cross-platform mobile apps with React Native.',
      category: 'Mobile'
    },
    {
      id: 7,
      title: 'DevOps Essentials',
      image: platformImage,
      description: 'Learn CI/CD, containerization, and cloud deployment.',
      category: 'DevOps'
    },
    {
      id: 8,
      title: 'UX/UI Design Principles',
      image: softwareImage,
      description: 'Create user-friendly interfaces with design thinking.',
      category: 'Design'
    }
  ];

  return (
    <div className="education-blog">
      <header className="blog-nav-header">
        <div className="header-content">
          <div className="logo-section">
            <img src={node1Image} alt="Logo" className="logo-image" />
          </div>
          <nav className="nav-menu">
            <Link to="/" className="nav-link">Home</Link>
            <Link to="/about" className="nav-link">About</Link>
            <Link to="/blog" className="nav-link">Blog</Link>
            <Link to="/services" className="nav-link">Services</Link>
            <Link to="/contact" className="nav-link">Contact</Link>
          </nav>
          <div className="auth-buttons">
            <Link to="/login" className="sign-in-btn">Sign In</Link>
            <Link to="/login" className="sign-up-btn">Sign Up</Link>
          </div>
        </div>
      </header>

      <header className="blog-header">
        <h1>Education Blog</h1>
        <p>Explore our collection of educational articles on technology and programming.</p>
      </header>
      <div className="blog-cards">
        {blogPosts.map(post => (
          <div key={post.id} className="blog-card">
            <img src={post.image} alt={post.title} className="card-image" />
            <div className="card-content">
              <span className="card-category">{post.category}</span>
              <h2 className="card-title">{post.title}</h2>
              <p className="card-description">{post.description}</p>
              <button className="read-more-btn">Read More</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EducationBlog;