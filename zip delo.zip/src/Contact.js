import React from 'react';
import { Link } from 'react-router-dom';
import './Contact.css';
import callImage from './assets/images/call.svg';
import arrowImage from './assets/images/arrow.png';
import psychologicalImage from './assets/images/Psychological.svg';
import leetcodeImage from './assets/images/Leetcode.svg';
import teamImage from './assets/images/team.svg';

const Contact = () => {
  return (
    <div className="contact-page">
      <header className="contact-header">
        <div className="header-content">
          <div className="logo-section">
            <img src={callImage} alt="Logo" className="logo-image" />
          </div>
          <nav className="nav-menu">
            <Link to="/" className="nav-link">Home</Link>
            <Link to="/about" className="nav-link">About</Link>
            <Link to="/services" className="nav-link">Services</Link>
            <Link to="/blog" className="nav-link">Blog</Link>
            <Link to="/contact" className="nav-link">Contact</Link>
          </nav>
          <div className="auth-buttons">
            <Link to="/login" className="sign-in-btn">Sign In</Link>
            <Link to="/login" className="sign-up-btn">Sign Up</Link>
          </div>
        </div>
      </header>

      <main className="contact-main">
        <section className="hero-section">
          <div className="hero-content">
            <h1>Contact Our Education Team</h1>
            <p>Get in touch with our web development and programming education experts. We're here to help you start or advance your career in tech.</p>
            <img src={arrowImage} alt="Hero" className="hero-image" />
          </div>
        </section>

        <section className="contact-info-section">
          <h2>Get In Touch</h2>
          <p>Whether you're a beginner looking to start your programming journey or an experienced developer seeking to expand your skills, our team is ready to assist you. We offer personalized guidance, course recommendations, and support throughout your learning process.</p>
          <img src={psychologicalImage} alt="Contact Info" className="section-image" />
        </section>

        <section className="contact-details">
          <h2>Contact Information</h2>

          <div className="contact-method">
            <h3>Phone Support</h3>
            <p>Our phone support team is available Monday through Friday, 9 AM to 6 PM EST. We provide immediate assistance for:</p>
            <ul>
              <li>Course enrollment questions</li>
              <li>Technical support for our learning platform</li>
              <li>Payment and billing inquiries</li>
              <li>General guidance on our educational programs</li>
            </ul>
            <p>Call us at: <strong>(555) 123-4567</strong></p>
            <p>For urgent technical issues, we recommend using our live chat or email support for faster response times.</p>
            <img src={callImage} alt="Phone Support" className="contact-image" />
          </div>

          <div className="contact-method">
            <h3>Email Support</h3>
            <p>Send us an email for detailed inquiries or when you need comprehensive assistance. Our email support covers:</p>
            <ul>
              <li>Detailed course information and curriculum questions</li>
              <li>Partnership and business inquiries</li>
              <li>Feedback and suggestions</li>
              <li>Technical documentation requests</li>
            </ul>
            <p>Email us at: <strong>support@educationplatform.com</strong></p>
            <p>We typically respond within 24 hours during business days. For complex inquiries, allow up to 48 hours for a detailed response.</p>
            <img src={leetcodeImage} alt="Email Support" className="contact-image" />
          </div>

          <div className="contact-method">
            <h3>Live Chat</h3>
            <p>Our live chat feature is available 24/7 for instant support. Perfect for quick questions about:</p>
            <ul>
              <li>Account login issues</li>
              <li>Course access problems</li>
              <li>Basic technical troubleshooting</li>
              <li>Quick enrollment guidance</li>
            </ul>
            <p>Look for the chat widget in the bottom right corner of our website. Our chat support team consists of experienced developers and educators who can provide immediate assistance.</p>
            <img src={teamImage} alt="Live Chat" className="contact-image" />
          </div>

          <div className="contact-method">
            <h3>Office Location</h3>
            <p>Visit our headquarters for in-person consultations or events. Our office is located in the heart of the tech district:</p>
            <address>
              Education Platform Headquarters<br />
              123 Tech Street<br />
              Silicon Valley, CA 94043<br />
              United States
            </address>
            <p>Office hours: Monday - Friday, 9 AM - 6 PM PST</p>
            <p>We host regular meetups, workshops, and networking events. Check our events calendar for upcoming in-person opportunities.</p>
            <img src={arrowImage} alt="Office Location" className="contact-image" />
          </div>
        </section>

        <section className="faq-section">
          <h2>Frequently Asked Questions</h2>
          <div className="faq-content">
            <div className="faq-item">
              <h4>How do I enroll in a course?</h4>
              <p>To enroll, visit our Services page, select the course that interests you, and click "Enroll Now". You'll be guided through a simple registration process where you can create an account and make payment.</p>
            </div>
            <div className="faq-item">
              <h4>What payment methods do you accept?</h4>
              <p>We accept all major credit cards, PayPal, and bank transfers. For enterprise clients, we also offer invoicing options with net-30 terms.</p>
            </div>
            <div className="faq-item">
              <h4>Do you offer refunds?</h4>
              <p>Yes, we offer a 30-day money-back guarantee on all our courses. If you're not satisfied with your learning experience, contact our support team for a full refund.</p>
            </div>
            <div className="faq-item">
              <h4>How long do I have access to course materials?</h4>
              <p>Once enrolled, you have lifetime access to all course materials, including future updates. Our platform allows you to learn at your own pace.</p>
            </div>
            <div className="faq-item">
              <h4>Do you provide certificates?</h4>
              <p>Yes, upon successful completion of any course, you'll receive a certificate of completion that you can add to your LinkedIn profile or resume.</p>
            </div>
          </div>
        </section>

        <section className="support-process">
          <h2>Our Support Process</h2>
          <p>We follow a structured approach to ensure you get the help you need efficiently:</p>
          <div className="process-steps">
            <div className="process-step">
              <h4>1. Initial Contact</h4>
              <p>Reach out through your preferred method - phone, email, or live chat.</p>
            </div>
            <div className="process-step">
              <h4>2. Issue Assessment</h4>
              <p>Our team quickly assesses your inquiry and determines the best solution approach.</p>
            </div>
            <div className="process-step">
              <h4>3. Resolution</h4>
              <p>We provide clear, actionable solutions or escalate complex issues to specialists.</p>
            </div>
            <div className="process-step">
              <h4>4. Follow-up</h4>
              <p>We follow up to ensure your issue is fully resolved and you're satisfied with the outcome.</p>
            </div>
          </div>
        </section>

        <section className="contact-form-section">
          <h2>Send Us a Message</h2>
          <p>Can't find what you're looking for? Send us a detailed message and we'll get back to you promptly.</p>
          <form className="contact-form">
            <div className="form-group">
              <label htmlFor="name">Full Name</label>
              <input type="text" id="name" name="name" required />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email Address</label>
              <input type="email" id="email" name="email" required />
            </div>
            <div className="form-group">
              <label htmlFor="subject">Subject</label>
              <select id="subject" name="subject" required>
                <option value="">Select a subject</option>
                <option value="enrollment">Course Enrollment</option>
                <option value="technical">Technical Support</option>
                <option value="billing">Billing Questions</option>
                <option value="partnership">Partnership Inquiry</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="message">Message</label>
              <textarea id="message" name="message" rows="5" required></textarea>
            </div>
            <button type="submit" className="submit-button">Send Message</button>
          </form>
        </section>
      </main>

      <footer className="contact-footer">
        <p>&copy; 2025 Education Platform. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Contact;