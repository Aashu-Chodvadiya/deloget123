import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Login.css';
import node1Image from './assets/images/node1.avif';
import pythonImage from './assets/images/python.jpg';
import uiImage from './assets/images/ui.svg';
import aiImage from './assets/images/ai.svg';

const Login = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  return (
    <div className="login-page">
      <header className="login-header">
        <div className="header-content">
          <div className="logo-section">
            <img src={node1Image} alt="Logo" className="logo-image" />
          </div>
          <nav className="nav-menu">
            <Link to="/" className="nav-link">Home</Link>
            <Link to="/about" className="nav-link">About</Link>
            <Link to="/services" className="nav-link">Services</Link>
            <Link to="/blog" className="nav-link">Blog</Link>
            <Link to="/contact" className="nav-link">Contact</Link>
            <Link to="/login" className="nav-link active">Login</Link>
          </nav>
          <button className="cta-button">Sign Up</button>
        </div>
      </header>

      <main className="login-main">
        <section className="hero-section">
          <div className="hero-content">
            <h1>Login to Your Learning Journey</h1>
            <p>Access your personalized dashboard, track progress, and continue your web development education seamlessly.</p>
            <img src={pythonImage} alt="Hero" className="hero-image" />
          </div>
        </section>

        <section className="login-form-section">
          <h2>{isSignUp ? 'Create Your Account' : 'Sign In to Your Account'}</h2>
          <p>{isSignUp ? 'Join our community of learners and start your web development journey today.' : 'Welcome back! Enter your credentials to access your educational resources and continue learning.'}</p>
          
          <div className="auth-toggle">
            <button 
              className={`toggle-btn ${!isSignUp ? 'active' : ''}`} 
              onClick={() => setIsSignUp(false)}
            >
              Sign In
            </button>
            <button 
              className={`toggle-btn ${isSignUp ? 'active' : ''}`} 
              onClick={() => setIsSignUp(true)}
            >
              Sign Up
            </button>
          </div>

          <form className="auth-form">
            {isSignUp && (
              <div className="form-group">
                <label htmlFor="fullName">Full Name</label>
                <input type="text" id="fullName" name="fullName" placeholder="Enter your full name" required />
              </div>
            )}
            <div className="form-group">
              <label htmlFor="email">Email Address</label>
              <input type="email" id="email" name="email" placeholder="Enter your email" required />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input type="password" id="password" name="password" placeholder="Enter your password" required />
            </div>
            {isSignUp && (
              <div className="form-group">
                <label htmlFor="confirmPassword">Confirm Password</label>
                <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm your password" required />
              </div>
            )}
            {!isSignUp && (
              <div className="form-options">
                <label className="checkbox-label">
                  <input type="checkbox" name="remember" />
                  Remember me
                </label>
                <a href="#" className="forgot-password">Forgot password?</a>
              </div>
            )}
            <button type="submit" className="login-button">
              {isSignUp ? 'Create Account' : 'Sign In'}
            </button>
          </form>
          
          {!isSignUp && <p className="signup-link">Don't have an account? <a href="#" onClick={() => setIsSignUp(true)}>Sign up here</a></p>}
          {isSignUp && <p className="signup-link">Already have an account? <a href="#" onClick={() => setIsSignUp(false)}>Sign in here</a></p>}
          
          <img src={uiImage} alt="Authentication Illustration" className="login-image" />
        </section>

        <section className="benefits-section">
          <h2>Why Login to Our Platform?</h2>
          <p>Accessing your account unlocks a world of educational opportunities and personalized learning experiences.</p>
          <img src={aiImage} alt="Benefits" className="section-image" />
        </section>

        <section className="detailed-benefits">
          <h2>Comprehensive Learning Benefits</h2>

          <div className="benefit-detail">
            <h3>Personalized Learning Paths</h3>
            <p>Upon logging in, you'll have access to customized learning recommendations based on your interests and skill level. Our advanced algorithm analyzes your progress and suggests the most relevant courses in web development, programming, and related technologies.</p>
            <ul>
              <li>AI-powered course recommendations</li>
              <li>Skill assessment and gap analysis</li>
              <li>Personalized study plans</li>
              <li>Adaptive learning modules</li>
            </ul>
            <p>This feature ensures that every logged-in user receives an education tailored specifically to their needs, maximizing learning efficiency and engagement.</p>
            <img src={node1Image} alt="Personalized Learning" className="benefit-image" />
          </div>

          <div className="benefit-detail">
            <h3>Progress Tracking and Analytics</h3>
            <p>Monitor your educational journey with detailed progress tracking. View completion rates, time spent on different topics, and performance metrics across all courses.</p>
            <ul>
              <li>Visual progress dashboards</li>
              <li>Time tracking and study analytics</li>
              <li>Certificate and achievement tracking</li>
              <li>Comparative performance insights</li>
            </ul>
            <p>Our analytics help you understand your learning patterns, identify strengths and weaknesses, and optimize your study habits for better results in web development and programming.</p>
            <img src={pythonImage} alt="Progress Tracking" className="benefit-image" />
          </div>

          <div className="benefit-detail">
            <h3>Interactive Community Access</h3>
            <p>Join a vibrant community of learners and experts. Participate in discussions, collaborate on projects, and network with professionals in the tech industry.</p>
            <ul>
              <li>Discussion forums and Q&A sections</li>
              <li>Peer code reviews and feedback</li>
              <li>Mentor connections and office hours</li>
              <li>Group projects and collaborative learning</li>
            </ul>
            <p>The community aspect of our platform transforms solitary learning into a social, supportive experience where you can learn from others and contribute your knowledge.</p>
            <img src={uiImage} alt="Community Access" className="benefit-image" />
          </div>

          <div className="benefit-detail">
            <h3>Exclusive Content and Resources</h3>
            <p>Logged-in users gain access to premium content, including advanced tutorials, industry insights, and exclusive resources not available to guests.</p>
            <ul>
              <li>Advanced coding challenges and projects</li>
              <li>Industry expert webinars and workshops</li>
              <li>Downloadable resources and cheat sheets</li>
              <li>Early access to new courses and features</li>
            </ul>
            <p>These exclusive resources provide deeper insights into web development trends, best practices, and cutting-edge technologies used in the industry.</p>
            <img src={aiImage} alt="Exclusive Content" className="benefit-image" />
          </div>

          <div className="benefit-detail">
            <h3>Certification and Career Support</h3>
            <p>Earn recognized certificates upon course completion and access career support features to advance your professional development in tech.</p>
            <ul>
              <li>Industry-recognized certificates</li>
              <li>Resume building and portfolio assistance</li>
              <li>Job placement support and interview prep</li>
              <li>LinkedIn integration and professional networking</li>
            </ul>
            <p>Our certification program validates your skills and helps you stand out in the competitive job market for web developers, programmers, and tech professionals.</p>
            <img src={node1Image} alt="Certification" className="benefit-image" />
          </div>

          <div className="benefit-detail">
            <h3>Offline Access and Sync</h3>
            <p>Download course materials for offline viewing and sync your progress across multiple devices seamlessly.</p>
            <ul>
              <li>Offline video and document access</li>
              <li>Cross-device progress synchronization</li>
              <li>Mobile app integration</li>
              <li>Automatic backup and data security</li>
            </ul>
            <p>This feature ensures you can continue learning anywhere, anytime, without worrying about internet connectivity or device limitations.</p>
            <img src={pythonImage} alt="Offline Access" className="benefit-image" />
          </div>
        </section>

        <section className="getting-started">
          <h2>Getting Started After Login</h2>
          <p>Once you've successfully logged in, here's what you can expect:</p>
          <div className="getting-started-steps">
            <div className="step">
              <h4>1. Dashboard Overview</h4>
              <p>Your personalized dashboard provides an overview of your enrolled courses, recent activity, and recommended next steps.</p>
            </div>
            <div className="step">
              <h4>2. Course Enrollment</h4>
              <p>Browse and enroll in new courses that match your learning goals and current skill level.</p>
            </div>
            <div className="step">
              <h4>3. Learning Path Selection</h4>
              <p>Choose from predefined learning paths or create a custom curriculum tailored to your career aspirations.</p>
            </div>
            <div className="step">
              <h4>4. Community Engagement</h4>
              <p>Connect with fellow learners, participate in discussions, and collaborate on projects.</p>
            </div>
            <div className="step">
              <h4>5. Progress Monitoring</h4>
              <p>Regularly check your progress, earn badges, and track your journey towards certification.</p>
            </div>
          </div>
        </section>

        <section className="support-section">
          <h2>Login Support and Troubleshooting</h2>
          <p>Having trouble logging in? Our support team is here to help. Here are some common issues and solutions:</p>
          <div className="support-topics">
            <div className="support-topic">
              <h4>Forgot Password</h4>
              <p>Use the "Forgot password?" link to reset your password. You'll receive an email with reset instructions.</p>
            </div>
            <div className="support-topic">
              <h4>Account Verification</h4>
              <p>New accounts require email verification. Check your inbox (and spam folder) for the verification email.</p>
            </div>
            <div className="support-topic">
              <h4>Browser Compatibility</h4>
              <p>Ensure you're using a modern browser like Chrome, Firefox, or Safari for the best experience.</p>
            </div>
            <div className="support-topic">
              <h4>Two-Factor Authentication</h4>
              <p>If 2FA is enabled, you'll need your authenticator app or SMS code to complete login.</p>
            </div>
          </div>
          <p>If you continue to experience issues, contact our support team through the Contact page for personalized assistance.</p>
        </section>
      </main>

      <footer className="login-footer">
        <p>&copy; 2025 Education Platform. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Login;