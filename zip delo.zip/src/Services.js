import React from 'react';
import { Link } from 'react-router-dom';
import './Services.css';
import softwareImage from './assets/images/Software.svg';
import testingImage from './assets/images/testing.svg';
import aiImage from './assets/images/ai.svg';
import appImage from './assets/images/app.svg';
import uiImage from './assets/images/ui.svg';
import platformImage from './assets/images/Platform.svg';

const Services = () => {
  return (
    <div className="services-page">
      <header className="services-header">
        <div className="header-content">
          <div className="logo-section">
            <img src={softwareImage} alt="Logo" className="logo-image" />
          </div>
          <nav className="nav-menu">
            <Link to="/" className="nav-link">Home</Link>
            <Link to="/about" className="nav-link">About</Link>
            <Link to="/services" className="nav-link">Services</Link>
            <Link to="/blog" className="nav-link">Blog</Link>
            <Link to="/contact" className="nav-link">Contact</Link>
          </nav>
          <div className="auth-buttons">
            <Link to="/login" className="sign-in-btn">Sign In</Link>
            <Link to="/login" className="sign-up-btn">Sign Up</Link>
          </div>
        </div>
      </header>

      <main className="services-main">
        <section className="hero-section">
          <div className="hero-content">
            <h1>Our Educational Services</h1>
            <p>Comprehensive web development and programming education services tailored for your learning needs.</p>
            <img src={testingImage} alt="Hero" className="hero-image" />
          </div>
        </section>

        <section className="overview-section">
          <h2>Service Overview</h2>
          <p>Our educational services cover the full spectrum of web development and programming education. From beginner-friendly introductions to advanced topics, we provide structured learning paths, hands-on projects, and expert guidance to help you master the skills needed in today's digital world.</p>
          <img src={aiImage} alt="Overview" className="section-image" />
        </section>

        <section className="detailed-services">
          <h2>Detailed Service Offerings</h2>

          <div className="service-detail">
            <h3>Custom Software Development Training</h3>
            <p>Learn to create custom software solutions tailored to specific business needs. Our comprehensive training covers:</p>
            <ul>
              <li>Requirements analysis and software design principles</li>
              <li>Front-end development with modern frameworks</li>
              <li>Back-end development and API design</li>
              <li>Database integration and management</li>
              <li>Testing and deployment strategies</li>
            </ul>
            <p>This service includes hands-on projects where students build real-world applications, gaining practical experience in the software development lifecycle.</p>
            <img src={softwareImage} alt="Software Development" className="service-image" />
            <Link to="/contact" className="service-link">Learn More About Custom Software Development</Link>
          </div>

          <div className="service-detail">
            <h3>Quality Assurance and Testing Education</h3>
            <p>Master the art of software testing to ensure robust, bug-free applications. Our QA training encompasses:</p>
            <ul>
              <li>Manual testing techniques and methodologies</li>
              <li>Automated testing with popular frameworks</li>
              <li>Performance testing and optimization</li>
              <li>Security testing fundamentals</li>
              <li>Test case design and execution</li>
            </ul>
            <p>Students learn to implement comprehensive testing strategies, including unit tests, integration tests, and end-to-end testing scenarios.</p>
            <img src={testingImage} alt="QA Testing" className="service-image" />
            <Link to="/contact" className="service-link">Learn More About QA Testing Education</Link>
          </div>

          <div className="service-detail">
            <h3>AI and Data Science Education</h3>
            <p>Dive into the world of artificial intelligence and data science with our specialized training program:</p>
            <ul>
              <li>Machine learning algorithms and models</li>
              <li>Data analysis and visualization techniques</li>
              <li>Neural networks and deep learning</li>
              <li>Natural language processing</li>
              <li>Computer vision applications</li>
            </ul>
            <p>This service provides practical experience with real datasets, teaching students to build predictive models and AI-powered applications.</p>
            <img src={aiImage} alt="AI and Data Science" className="service-image" />
            <Link to="/contact" className="service-link">Learn More About AI Education</Link>
          </div>

          <div className="service-detail">
            <h3>Mobile App Development Training</h3>
            <p>Learn to build cross-platform mobile applications for iOS and Android:</p>
            <ul>
              <li>React Native and Flutter frameworks</li>
              <li>Native iOS development with Swift</li>
              <li>Native Android development with Kotlin</li>
              <li>App store deployment and publishing</li>
              <li>Mobile UI/UX design principles</li>
            </ul>
            <p>Students create fully functional mobile apps, learning about platform-specific optimizations and user experience best practices.</p>
            <img src={appImage} alt="Mobile Development" className="service-image" />
            <Link to="/contact" className="service-link">Learn More About Mobile Development</Link>
          </div>

          <div className="service-detail">
            <h3>UI/UX Design Education</h3>
            <p>Master the principles of user interface and user experience design:</p>
            <ul>
              <li>User research and persona development</li>
              <li>Wireframing and prototyping tools</li>
              <li>Visual design and branding</li>
              <li>Usability testing and iteration</li>
              <li>Design systems and component libraries</li>
            </ul>
            <p>This comprehensive design education teaches students to create intuitive, beautiful, and accessible user interfaces for web and mobile applications.</p>
            <img src={uiImage} alt="UI/UX Design" className="service-image" />
            <Link to="/contact" className="service-link">Learn More About UI/UX Design</Link>
          </div>

          <div className="service-detail">
            <h3>Platform and Infrastructure Training</h3>
            <p>Learn about cloud platforms, DevOps, and infrastructure management:</p>
            <ul>
              <li>Cloud computing with AWS, Azure, or GCP</li>
              <li>Containerization with Docker and Kubernetes</li>
              <li>CI/CD pipeline implementation</li>
              <li>Infrastructure as Code (IaC)</li>
              <li>Monitoring and logging strategies</li>
            </ul>
            <p>Students gain hands-on experience deploying and managing scalable applications in cloud environments, ensuring high availability and security.</p>
            <img src={platformImage} alt="Platform and Infrastructure" className="service-image" />
            <Link to="/contact" className="service-link">Learn More About Platform Training</Link>
          </div>
        </section>

        <section className="methodology-section">
          <h2>Our Teaching Methodology</h2>
          <p>We employ a project-based learning approach that combines theoretical knowledge with practical application:</p>
          <div className="methodology-details">
            <div className="methodology-item">
              <h4>Interactive Lectures</h4>
              <p>Engaging video lessons and live sessions with industry experts.</p>
            </div>
            <div className="methodology-item">
              <h4>Hands-on Projects</h4>
              <p>Real-world projects that build a professional portfolio.</p>
            </div>
            <div className="methodology-item">
              <h4>Mentorship Program</h4>
              <p>One-on-one guidance from experienced developers.</p>
            </div>
            <div className="methodology-item">
              <h4>Community Support</h4>
              <p>Access to forums, study groups, and peer collaboration.</p>
            </div>
          </div>
        </section>

        <section className="contact-section">
          <h2>Ready to Start Learning?</h2>
          <p>Choose the service that best fits your educational goals and begin your journey to becoming a skilled web developer.</p>
          <button className="contact-button">Enroll Now</button>
        </section>
      </main>

      <footer className="services-footer">
        <p>&copy; 2025 Education Services. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Services;