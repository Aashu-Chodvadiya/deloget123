import React from 'react';
import { Link } from 'react-router-dom';
import './About.css';
import node1Image from './assets/images/node1.avif';
import pythonImage from './assets/images/python.jpg';
import uiImage from './assets/images/ui.svg';
import aiImage from './assets/images/ai.svg';

const About = () => {
  return (
    <div className="about-page">
      <header className="about-header">
        <div className="header-content">
          <div className="logo-section">
            <img src={node1Image} alt="Logo" className="logo-image" />
          </div>
          <nav className="nav-menu">
            <Link to="/" className="nav-link">Home</Link>
            <Link to="/about" className="nav-link">About</Link>
            <Link to="/blog" className="nav-link">Blog</Link>
            <Link to="/services" className="nav-link">Services</Link>
            <Link to="/contact" className="nav-link">Contact</Link>
          </nav>
          <div className="auth-buttons">
            <Link to="/login" className="sign-in-btn">Sign In</Link>
            <Link to="/login" className="sign-up-btn">Sign Up</Link>
          </div>
        </div>
      </header>

      <main className="about-main">
        <section className="hero-section">
          <div className="hero-content">
            <h1>About Our Education Platform</h1>
            <p>Empowering learners with comprehensive web development and programming education.</p>
            <img src={pythonImage} alt="Hero" className="hero-image" />
          </div>
        </section>

        <section className="mission-section">
          <h2>Our Mission</h2>
          <p>Our mission is to provide high-quality, accessible education in web development, programming, and related technologies. We believe that everyone should have the opportunity to learn and grow in the digital world.</p>
          <img src={uiImage} alt="Mission" className="section-image" />
        </section>

        <section className="courses-section">
          <h2>What We Offer</h2>
          <div className="course-details">
            <div className="course-item">
              <h3>Web Development Fundamentals</h3>
              <p>Learn HTML, CSS, and JavaScript from scratch. Build responsive websites and understand the core principles of front-end development.</p>
              <ul>
                <li>HTML5 and semantic markup</li>
                <li>CSS3 and modern styling techniques</li>
                <li>JavaScript fundamentals and DOM manipulation</li>
                <li>Responsive design with media queries</li>
              </ul>
            </div>
            <div className="course-item">
              <h3>Advanced JavaScript</h3>
              <p>Dive deep into JavaScript with ES6+, asynchronous programming, and modern frameworks.</p>
              <ul>
                <li>ES6+ features and syntax</li>
                <li>Asynchronous programming with Promises and async/await</li>
                <li>React.js for building user interfaces</li>
                <li>Node.js for server-side development</li>
              </ul>
            </div>
            <div className="course-item">
              <h3>Full-Stack Development</h3>
              <p>Master both front-end and back-end technologies to become a complete web developer.</p>
              <ul>
                <li>Database design and management</li>
                <li>RESTful API development</li>
                <li>Authentication and security</li>
                <li>Deployment and DevOps basics</li>
              </ul>
            </div>
          </div>
          <img src={aiImage} alt="Courses" className="section-image" />
        </section>

        <section className="team-section">
          <h2>Our Team</h2>
          <p>Our experienced instructors and developers are passionate about sharing knowledge and helping students succeed.</p>
          <div className="team-members">
            <div className="team-member">
              <img src={node1Image} alt="Instructor 1" />
              <h4>John Doe</h4>
              <p>Senior Web Developer</p>
            </div>
            <div className="team-member">
              <img src={pythonImage} alt="Instructor 2" />
              <h4>Jane Smith</h4>
              <p>Full-Stack Engineer</p>
            </div>
            <div className="team-member">
              <img src={uiImage} alt="Instructor 3" />
              <h4>Bob Johnson</h4>
              <p>UI/UX Designer</p>
            </div>
          </div>
        </section>

        <section className="contact-section">
          <h2>Get in Touch</h2>
          <p>Ready to start your learning journey? Contact us today!</p>
          <button className="contact-button">Contact Us</button>
        </section>
      </main>

      <footer className="about-footer">
        <p>&copy; 2025 Education Platform. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default About;